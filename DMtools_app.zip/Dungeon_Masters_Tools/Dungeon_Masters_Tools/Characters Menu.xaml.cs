﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CsvHelper;
namespace Dungeon_Masters_Tools
{
    public partial class Characters_Menu : Page
    {
        string campaignPath;
        string datapath = "";
        MainWindow mainWindow;
        public Characters_Menu(string cPath, MainWindow mw)
        {
            InitializeComponent();
            mainWindow = mw;
            campaignPath = cPath;
            StartupRefresh(campaignPath);
        }
        string[] monsters;
        public void StartupRefresh(string campaignPath)
        {
            datapath = campaignPath + @"\Characters";
            string[] players = CleanString(Directory.GetDirectories(datapath + @"\Players"), datapath + @"\Players");
            monsters = CleanString(Directory.GetDirectories(datapath + @"\Monsters"), datapath + @"\Monsters");
            string[] npcs = CleanString(Directory.GetDirectories(datapath + @"\NPC's"), datapath + @"\NPC's");
            playersList.ItemsSource = players;
            monstersList.ItemsSource = monsters;
            NPCList.ItemsSource = npcs;
        }
        public string[] CleanString(string[] dirtyStrings, string dirt)
        {
            string[] cleanStrings = new string[dirtyStrings.Length];
            for (int i = 0; i < dirtyStrings.Length; i++)
            {
                cleanStrings[i] = dirtyStrings[i].Replace(dirt + @"\", "");
            }
            return cleanStrings;
        }

        private void PlayersList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //MessageBox.Show(datapath + @"\Players\" + playersList.SelectedItem.ToString());
            CharacterSheet cs = new CharacterSheet(datapath + @"\Players\" + playersList.SelectedItem.ToString(), false);
            cs.ShowDialog();
        }

        private void AddPlayer_Click(object sender, RoutedEventArgs e)
        {
            popup p = new popup("Player Name");
            p.ShowDialog();
            Directory.CreateDirectory(datapath + @"\Players\" + p.input);
            CharacterSheet cs = new CharacterSheet(datapath + @"\Players\" + p.input, true);
            StartupRefresh(campaignPath);
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            mainWindow.MainFrame.Content = mainWindow.campaignMenu;
        }

        private void AddMonster_Click(object sender, RoutedEventArgs e)
        {
            MonsterView mv = new MonsterView(datapath, true, "");
            mv.ShowDialog();
        }

        private void MonstersList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            MonsterView mv = new MonsterView(datapath + @"\Monsters\", false, monstersList.SelectedItem.ToString());
            mv.ShowDialog();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            StartupRefresh(campaignPath);
        }

        private void Add_NPC_Click(object sender, RoutedEventArgs e)
        {
            popup p = new popup("NPC Name");
            p.ShowDialog();
            Directory.CreateDirectory(datapath + @"\NPC's\" + p.input);
            CharacterSheet cs = new CharacterSheet(datapath + @"\NPC's\" + p.input, true);
            StartupRefresh(campaignPath);
        }

        private void NPCList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CharacterSheet cs = new CharacterSheet(datapath + @"\NPC's\" + NPCList.SelectedItem.ToString(), false);
            cs.ShowDialog();
        }
    }
}
