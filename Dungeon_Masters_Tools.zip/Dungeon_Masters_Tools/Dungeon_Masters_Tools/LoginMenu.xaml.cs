﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dungeon_Masters_Tools
{
    /// <summary>
    /// Interaction logic for LoginMenu.xaml
    /// </summary>
    public partial class LoginMenu : Page
    {
        public bool signIn = true;
        public string keysPath = "";
        MainWindow window;
        public LoginMenu(MainWindow mainWindow, string datapath)
        {
            InitializeComponent();
            keysPath = datapath + @"\DMtools\keys.text";
            window = mainWindow;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (signIn == true)
            {
                Login();
            }
            else
            {
                CreateKey();
            }
        }
         public void Login()
         {
             bool loginSuccessful = false;
             string input = keyInput.Text;
             string[] keys = File.ReadAllLines(keysPath);
             string[] decodedKeys = new string[keys.Length];
             for (int i = 0; i < keys.Length; i++)
             {
                 decodedKeys[i] = Base64Decode(keys[i]); ;
             }

             for (int i = 0; i < decodedKeys.Length; i++)
             {
                 if (decodedKeys[i] == input)
                 {
                     loginSuccessful = true;
                 }
             }

             if (loginSuccessful == true)
             {
                 MessageBox.Show("Login Successful");
                window.OpenApp();
             }
             else
             {
                 MessageBox.Show("Login Unsuccessful");
             }
        }
        public void CreateKey()
        {
            
            
                string newKey = Base64Encode(keyInput.Text);
                StreamWriter write = File.AppendText(keysPath);
                
                write.WriteLine(newKey + write.NewLine);
           // write.WriteLine("hahagobrrr");
                write.Close();
            
                MessageBox.Show("Successfully added");
            
            //catch (Exception ex)
            //{
           //     MessageBox.Show(ex.Message);

           // }
        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }
        //Switch to create or login
        private void createKeyButton_Click(object sender, RoutedEventArgs e)
        {
            if (signIn == true)
            {
                createLoginButton.Content = "Sign In";
                label.Content = "Please enter the key you wish to use";
                submitButton.Content = "Create Key";
                signIn = false;
            }
            else
            {
                createLoginButton.Content = "Create Key";
                label.Content = "Please enter your key";
                submitButton.Content = "Login";
                signIn = true;
            }

        }
    }
}
