﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Dungeon_Masters_Tools
{
    /// <summary>
    /// Interaction logic for MapViewer.xaml
    /// </summary>
    public partial class MapViewer : Window
    {
        string mapsPath = "";
        List<BitmapImage> maps;
        int imagenum = 0;
        public MapViewer(string campaignPath, string assetsPath)
        {
            InitializeComponent();
            maps = new List<BitmapImage>();
            mapsPath = campaignPath + @"\Maps";

            previousIcon.Source = new BitmapImage(new Uri(assetsPath + "previousIcon.png", UriKind.RelativeOrAbsolute));
            nextIcon.Source = new BitmapImage(new Uri(assetsPath + "nextIcon.png", UriKind.RelativeOrAbsolute));
            string[] names = Directory.GetFiles(mapsPath);
            for (int i = 0; i < names.Length; i++)
            {
                maps.Add(new BitmapImage(new Uri(names[i], UriKind.RelativeOrAbsolute)));
            }
            mapImage.Source = maps[imagenum];
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (imagenum + 1 <= maps.Count)
                    mapImage.Source = maps[imagenum += 1];
            }
            catch (Exception ex)
            {
                MessageBox.Show("No more images to show");
                imagenum -= 1;
            }

        }

        private void PreviousButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (imagenum - 1 >= 0)
                    mapImage.Source = maps[imagenum -= 1];
            }
            catch(Exception ex)
            {
                MessageBox.Show("No more images to show");
                imagenum += 1;
            }

        }
        //Close
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Add_Map_Click(object sender, RoutedEventArgs e)
        {
            
            Microsoft.Win32.OpenFileDialog dialog = new Microsoft.Win32.OpenFileDialog();


         
            dialog.DefaultExt = ".png";
            dialog.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg";


            
            Nullable<bool> result = dialog.ShowDialog();


            
            if (result == true)
            {
                
                string filename = dialog.FileName;
                BitmapImage newImage = new BitmapImage(new Uri(dialog.FileName, UriKind.RelativeOrAbsolute));
                maps.Add(newImage);
                mapImage.Source = newImage;
                MessageBox.Show(dialog.SafeFileName);
                File.Copy(filename, mapsPath + @"\" + dialog.SafeFileName);
            }
        }
    }
}
