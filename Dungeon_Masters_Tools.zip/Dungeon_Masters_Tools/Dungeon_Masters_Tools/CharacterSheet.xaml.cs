﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CsvHelper;
namespace Dungeon_Masters_Tools
{
    /// <summary>
    /// Interaction logic for CharacterSheet.xaml
    /// </summary>
    public partial class CharacterSheet : Window
    {
        PlayerStatistics pS;
        string csvPath = "";
        public CharacterSheet(string characterPath, bool isnew)
        {

            
            InitializeComponent();
            csvPath = characterPath + @"\CharacterStatistics.csv";
            backImage.Source = (new BitmapImage(new Uri(AppDomain.CurrentDomain.BaseDirectory + @"\Assets\characSheet.png")));
            if (isnew == false)
            {
                PlayerStatistics[] ps;
                using (var reader = new StreamReader(characterPath + @"\CharacterStatistics.csv"))
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {
                    var records = csv.GetRecords<PlayerStatistics>();
                    ps = records.ToArray();
                    reader.Close();
                }
                
                pS = ps[0];
                this.Title = pS.Name + "'s Character Sheet";
                FillUI(pS);
                // MessageBox.Show(pS.Name + " " + pS.Class);
                //implement scroll to zoom
            }
            else
            {
                
                PlayerStatistics[] placeholder = new PlayerStatistics[1];
                pS = new PlayerStatistics();
                placeholder[0] = pS;
                using (var writer = new StreamWriter(characterPath + @"\CharacterStatistics.csv"))
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    csv.WriteRecords(placeholder);
                }
                CharacterSheet c = new CharacterSheet(characterPath, false);
                c.ShowDialog();
                this.Close();
            }
        }
        public void FillUI(PlayerStatistics pS)
        {
            strText.Text = pS.Strength.ToString();
            dexText.Text = pS.Dexterity.ToString();
            conText.Text = pS.Constitution.ToString();
            intText.Text = pS.Intelligence.ToString();
            wisText.Text = pS.Wisdom.ToString();
            chaText.Text = pS.Charisma.ToString();

            strBonusText.Text = pS.strBonus.ToString();
            dexBonusText.Text = pS.dexBonus.ToString();
            conBonusText.Text = pS.conBonus.ToString();
            intBonusText.Text = pS.intBonus.ToString();
            wisBonusText.Text = pS.wisBonus.ToString();
            chaBonusText.Text = pS.chaBonus.ToString();

            acText.Text = pS.ArmourClass.ToString();
            initText.Text = pS.Initiative.ToString();
            maxHPText.Text = pS.MaxHitPoints.ToString();
            currHPText.Text = pS.CurrentHP.ToString();

            speedText.Text = pS.Speed.ToString();
            insText.Text = pS.dexBonus.ToString();
            playerNameText.Text = pS.UsersName;
            classText.Text = pS.Class;
            levelText.Text = pS.Level;
            backgroundText.Text = pS.Background;
            raceText.Text = pS.Race;
            alignmentText.Text = pS.Alignment;
            characNameText.Text = pS.Name;
            xpText.Text = pS.XP;

            cpText.Text = pS.CP;
            spText.Text = pS.SP;
            epText.Text = pS.EP;
            gpText.Text = pS.GP;
            ppText.Text = pS.PP;
            equipText.Text = pS.Equipment;
            proflangText.Text = pS.ProfnLang;
            persTraitText.Text = pS.PersTrait;
            featTraitText.Text = pS.FeatTrait;
            idealsText.Text = pS.Ideals;
            bondsText.Text = pS.Bonds;
            flawsText.Text = pS.Flaws;
            weaponsText.Text = pS.Weapons;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Create placeholder array to assign class to first slot (csvwriter class compatibility workaround)
            PlayerStatistics[] placeholder = new PlayerStatistics[1];
            PlayerStatistics updatedStats = new PlayerStatistics();
            //Set all values to textboxes(inputs), wrapped in try catch to prevent crashing and provide error message

            
            try
            {
                updatedStats.Strength = Int32.Parse(strText.Text);
                updatedStats.Dexterity = Int32.Parse(dexText.Text);
                updatedStats.Constitution = Int32.Parse(conText.Text);
                updatedStats.Intelligence = Int32.Parse(intText.Text);
                updatedStats.Wisdom = Int32.Parse(wisText.Text);
                updatedStats.Charisma = Int32.Parse(chaText.Text);

                updatedStats.strBonus = Int32.Parse(strBonusText.Text);
                updatedStats.dexBonus = Int32.Parse(dexBonusText.Text);
                updatedStats.conBonus = Int32.Parse(conBonusText.Text);
                updatedStats.intBonus = Int32.Parse(intBonusText.Text);
                updatedStats.wisBonus = Int32.Parse(wisBonusText.Text);
                updatedStats.chaBonus = Int32.Parse(chaBonusText.Text);
                
                updatedStats.ArmourClass = Int32.Parse(acText.Text);
                updatedStats.Speed = Int32.Parse(speedText.Text);
                updatedStats.Initiative = Int32.Parse(initText.Text);
                updatedStats.Name = characNameText.Text;
                updatedStats.UsersName = playerNameText.Text;
                updatedStats.Class = classText.Text;
                updatedStats.Race = raceText.Text;
                updatedStats.Alignment = alignmentText.Text;
                updatedStats.Background = backgroundText.Text;
                updatedStats.Level = levelText.Text;
                updatedStats.XP = xpText.Text;
                updatedStats.MaxHitPoints = Int32.Parse(maxHPText.Text);
                updatedStats.CurrentHP = Int32.Parse(currHPText.Text);

                updatedStats.CP = cpText.Text;
                updatedStats.SP = spText.Text;
                updatedStats.EP = epText.Text;
                updatedStats.GP = gpText.Text;
                updatedStats.PP = ppText.Text;

                updatedStats.Equipment = equipText.Text;
                updatedStats.ProfnLang = proflangText.Text;
                updatedStats.PersTrait = persTraitText.Text;
                updatedStats.FeatTrait = featTraitText.Text;
                updatedStats.Ideals = idealsText.Text;
                updatedStats.Bonds = bondsText.Text;
                updatedStats.Flaws = flawsText.Text;
                updatedStats.Weapons = weaponsText.Text;
                placeholder[0] = updatedStats;
//Write all values to file
                using (var writer = new StreamWriter(csvPath))
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    csv.WriteRecords(placeholder);
                }
                this.Close();
            }
            catch(Exception ex)
            {
                //Show error message
                MessageBox.Show(ex.Message);
            }


        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //Close
            this.Close();
        }
    }

    public class PlayerStatistics
    {
        public string Name { get; set; }
        public string UsersName { get; set; }
        public string Race { get; set; }
        public string Background { get; set; }
        public string Class { get; set; }
        public string Level { get; set; }
        public string Alignment { get; set; }
        public string XP { get; set; }

        public int Strength { get; set; }
        public int Dexterity { get; set; }
        public int Constitution { get; set; }
        public int Intelligence { get; set; }
        public int Wisdom { get; set; }
        public int Charisma { get; set; }

        public int strBonus { get; set; }
        public int dexBonus { get; set; }
        public int conBonus { get; set; }
        public int intBonus { get; set; }
        public int wisBonus { get; set; }
        public int chaBonus { get; set; }

        public int ArmourClass { get; set; }
        public int Initiative { get; set; }
        public int MaxHitPoints { get; set; }
        public int CurrentHP { get; set; }
        public int Perception { get; set; }
        public int Speed { get; set; }

        public string CP { get; set; }
        public string SP { get; set; }
        public string EP { get; set; }
        public string GP { get; set; }
        public string PP { get; set; }

        public string Equipment { get; set; }
        public string ProfnLang { get; set; }
        public string FeatTrait { get; set; }
        public string PersTrait { get; set; }
        public string Ideals { get; set; }
        public string Bonds { get; set; }
        public string Flaws { get; set; }
        public string Weapons { get; set; }

    }
}
