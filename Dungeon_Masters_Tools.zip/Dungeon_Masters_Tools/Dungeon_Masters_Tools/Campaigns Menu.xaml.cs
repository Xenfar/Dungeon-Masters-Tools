﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dungeon_Masters_Tools
{
    /// <summary>
    /// Interaction logic for Campaigns_Menu.xaml
    /// </summary>
    public partial class Campaigns_Menu : Page
    {
        string datapath = "";
        string startupPath = "";
        MainWindow mW;
        public Campaigns_Menu(MainWindow mainWindow, string dp)
        {
            InitializeComponent();
            datapath = dp + @"\DMtools\";
            mW = mainWindow;
            LoadCampaigns();
            startupPath = AppDomain.CurrentDomain.BaseDirectory;
            //load title image
            campaignTitleImage.Source = new BitmapImage(new Uri((startupPath + @"\Assets\campaignTitleImage.jpg"), UriKind.RelativeOrAbsolute));
            campaignTitleImage.Height = 353/2.5;
            campaignTitleImage.Width = 1469/2.5;

            newCampaignImage.Source = new BitmapImage(new Uri((startupPath + @"\Assets\newCampaignImage.jpg"), UriKind.RelativeOrAbsolute));
            newCampaignButton.Height = 301 / 4;
            newCampaignButton.Width = 1520 / 4;
        }
        public void LoadCampaigns()
        {
            string[] subdirectories = Directory.GetDirectories(datapath);

            for (int i = 0; i < subdirectories.Length; i++)
            {
                CreateUI(subdirectories[i]);
            }
        }
        public void CreateUI(string campaignPath)
        {
            string campaignName = campaignPath.Replace(datapath, "");

            //Create Button
            Button campaignButton = new Button();
            campaignButton.Name = campaignName;
            campaignButton.Click += Campaign_Click;
            campaignButton.Width = 150;
            campaignButton.Height = 172;
            campaignButton.HorizontalAlignment = HorizontalAlignment.Center;
            campaignButton.VerticalAlignment = VerticalAlignment.Center;

            //Create UI container for button
            StackPanel container = new StackPanel();
            container.Name = "Container";

            //Create Label 
            Label campaignNameLabel = new Label();
            campaignNameLabel.Content = campaignName;
            //campaignNameLabel.Height = 20;
            campaignNameLabel.FontWeight = FontWeights.Bold;
            campaignNameLabel.VerticalAlignment = VerticalAlignment.Top;
            campaignNameLabel.HorizontalContentAlignment = HorizontalAlignment.Center;
            campaignNameLabel.VerticalContentAlignment = VerticalAlignment.Center;
            campaignNameLabel.FontSize = 14;
            //Create and import default map image
            Image campaignMap = new Image();
            campaignMap.Stretch = Stretch.None;

            campaignMap.VerticalAlignment = VerticalAlignment.Top;
            campaignMap.Source = new BitmapImage(new Uri(datapath + campaignName + @"\Maps\defaultmap.jpg", UriKind.RelativeOrAbsolute));
            campaignMap.Height = campaignMap.Source.Height - 10;
            //Add label and image to container, add container to button.
            container.Children.Add(campaignMap);
            container.Children.Add(campaignNameLabel);
            campaignButton.Content = container;
            
            campaignList.Children.Add(campaignButton);

            //Add padding
            Label padding = new Label();
            padding.Width = 15;
            campaignList.Children.Add(padding);

        }
        private void Campaign_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            mW.OpenCampaign(datapath + button.Name, button.Name);
        }

        private void newCampaignButton_Click(object sender, RoutedEventArgs e)
        {
            //Create popup input for campaign name and then use that to create campaign directory and maps, characters, places subdirectories
            popup popup = new popup("Campaign Name");
            popup.ShowDialog();
            Directory.CreateDirectory(datapath + popup.input);
            Directory.CreateDirectory(datapath + popup.input + @"\Maps");
            Directory.CreateDirectory(datapath + popup.input + @"\Characters");
            Directory.CreateDirectory(datapath + popup.input + @"\Characters\Players");
            Directory.CreateDirectory(datapath + popup.input + @"\Characters\Monsters");
            Directory.CreateDirectory(datapath + popup.input + @"\Characters\NPC's");
            Directory.CreateDirectory(datapath + popup.input + @"\Places");
            //Copy default map from \Assets to new directory \Maps
            File.Copy(startupPath + @"Assets\defaultmap.jpg", datapath + popup.input + @"\Maps\defaultmap.jpg");
            //Load new campaign information in to UI creation system
            CreateUI(datapath + popup.input);
        }
    }
}
