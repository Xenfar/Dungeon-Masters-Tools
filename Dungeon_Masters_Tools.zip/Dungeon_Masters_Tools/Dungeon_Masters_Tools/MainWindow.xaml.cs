﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dungeon_Masters_Tools
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public LoginMenu loginMenu;
        public Campaigns_Menu cm;
        public Campaign_Menu campaignMenu;
        public string datapath = "";
        public MainWindow()
        {
            
            InitializeComponent();
            MessageBox.Show(AppDomain.CurrentDomain.BaseDirectory);
            datapath = (AppDomain.CurrentDomain.BaseDirectory + @"\DMtools");
            loginMenu = new LoginMenu(this, datapath);
            MainFrame.Content = loginMenu;
        }
        public void OpenApp()
        {
            cm = new Campaigns_Menu(this, datapath);
            MainFrame.Content = cm;
            loginMenu.KeepAlive = false;
            
        }
        public void OpenCampaign(string campaignPath, string name)
        {
            campaignMenu = new Campaign_Menu(campaignPath, this, name);
            MainFrame.Content = campaignMenu;
        }

    }
}
