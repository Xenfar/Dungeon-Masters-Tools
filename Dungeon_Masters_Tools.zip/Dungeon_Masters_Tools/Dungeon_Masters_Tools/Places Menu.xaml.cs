﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dungeon_Masters_Tools
{
    /// <summary>
    /// Interaction logic for Places_Menu.xaml
    /// </summary>
    public partial class Places_Menu : Page
    {
        string campaignPath;
        string datapath = "";
        MainWindow mainWindow;
        Building[] buildings;
        Town[] towns;
        Castle[] castles;
        public Places_Menu(string cPath, MainWindow mw)
        {
            InitializeComponent();
            mainWindow = mw;
            campaignPath = cPath;
            StartupRefresh(campaignPath);
        }
        public void StartupRefresh(string campaignPath)
        {
            datapath = campaignPath + @"\Places";
            //Check is csv files exist, if not create files and write empty temp file.
            if (File.Exists(datapath + @"\Buildings.csv") == false)
            {
                using (var writer = new StreamWriter(datapath + @"\Buildings.csv"))
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    Building[] temp = new Building[1];

                    csv.WriteRecords(temp);
                }
            }
            if (File.Exists(datapath + @"\Towns.csv") == false)
            {
                using (var writer = new StreamWriter(datapath + @"\Towns.csv"))
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    Town[] temp = new Town[1];

                    csv.WriteRecords(temp);
                }
            }
            if (File.Exists(datapath + @"\Castles.csv") == false)
            {
                using (var writer = new StreamWriter(datapath + @"\Castles.csv"))
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    Castle[] temp = new Castle[1];

                    csv.WriteRecords(temp);
                }
            }

            //Read Building data in to list
            using (var reader = new StreamReader(datapath + @"\Buildings.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = csv.GetRecords<Building>();
                buildings = records.ToArray();
                reader.Close();
            }
            //Read Town data in to list
            using (var reader = new StreamReader(datapath + @"\Towns.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = csv.GetRecords<Town>();
                towns = records.ToArray();
                reader.Close();
            }
            //Read Castle data in to list
            using (var reader = new StreamReader(datapath + @"\Castles.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = csv.GetRecords<Castle>();
                castles = records.ToArray();
                reader.Close();
            }

            //Get names of buildings and parse to string array for selection box to use
            string[] buildingNames = new string[buildings.Length];
            for (int i = 0; i < buildingNames.Length; i++)
            {
                buildingNames[i] = buildings[i].Name;
            }
            //Parse names to selection box
            buildingsList.ItemsSource = buildingNames;

            //Get names of towns and parse to string array for selection box to use
            string[] townNames = new string[towns.Length];
            for (int i = 0; i < townNames.Length; i++)
            {
                townNames[i] = towns[i].Name;
            }
            //Parse names to selection box
            townsList.ItemsSource = townNames;

            //Get names of castles and parse to string array for selection box to use
            string[] castleNames = new string[castles.Length];
            for (int i = 0; i < castleNames.Length; i++)
            {
                castleNames[i] = castles[i].Name;
            }
            //Parse names to selection box
            castlesList.ItemsSource = castleNames;
        }
        //Convenient class to remove a string from all strings in a string array
        public string[] CleanString(string[] dirtyStrings, string dirt)
        {
            string[] cleanStrings = new string[dirtyStrings.Length];
            for (int i = 0; i < dirtyStrings.Length; i++)
            {
                cleanStrings[i] = dirtyStrings[i].Replace(dirt + @"\", "");
            }
            return cleanStrings;
        }
        //Find and display selected building
        public Building selectedBuilding;
        private void BuildingsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedBuilding = buildings[buildingsList.SelectedIndex];
            PlaceCreator pc = new PlaceCreator(this,1, campaignPath, false);
            pc.ShowDialog();


        }
        //Display building creator
        private void AddBuilding_Click(object sender, RoutedEventArgs e)
        {
             PlaceCreator pc = new PlaceCreator(this,1, campaignPath, true);
             pc.ShowDialog();
        }
        //Display campaign menu
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            mainWindow.MainFrame.Content = mainWindow.campaignMenu;
        }
        //Display Town Creator
        private void AddTown_Click(object sender, RoutedEventArgs e)
        {
             PlaceCreator pc = new PlaceCreator(this,2, campaignPath, true);
             pc.ShowDialog();
        }
        //Find and display selected town
        public Town selectedTown;
        private void TownsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedTown = towns[townsList.SelectedIndex];
            PlaceCreator pc = new PlaceCreator(this, 2, campaignPath, false);
            pc.ShowDialog();
        }
        //Refresh items list, read csv files again
        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            StartupRefresh(campaignPath);
        }
        //Display Castle Creator
        private void AddCastle_Click(object sender, RoutedEventArgs e)
        {
             PlaceCreator pc = new PlaceCreator(this,3, campaignPath, true);
             pc.ShowDialog();
        }
        //Find and display selected castle
        public Castle selectedCastle;
        private void CastlesList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedCastle = castles[castlesList.SelectedIndex];
            PlaceCreator pc = new PlaceCreator(this, 3, campaignPath, false);
            pc.ShowDialog();
        }
    }
}
