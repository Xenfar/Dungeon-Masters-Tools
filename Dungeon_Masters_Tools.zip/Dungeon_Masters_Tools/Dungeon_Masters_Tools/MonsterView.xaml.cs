﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CsvHelper;
namespace Dungeon_Masters_Tools
{
    /// <summary>
    /// Interaction logic for MonsterView.xaml
    /// </summary>
    public partial class MonsterView : Window
    {
        string monsterPath = "";
        Monster[] monsters;
        Monster[] selectedMonster = new Monster[1];
        bool isNew = false;
        string Name = "";
        public MonsterView(string campPath, bool isnew, string name)
        {
            InitializeComponent();
            isNew = isnew;
            AbilityScores.Source = (new BitmapImage(new Uri(AppDomain.CurrentDomain.BaseDirectory + @"\Assets\monsterscores.png")));
            if (isNew == false)
            {
                monsterPath = campPath;
                MessageBox.Show(monsterPath);
                monsterPicker.Visibility = Visibility.Hidden;
                Name = name;
                ReadOldData();
                
            }
            else
            {
                monsterPath = campPath + @"\Monsters";
                ReadNewData();
            }
            
        }

        public void ReadNewData()
        {
            using (var reader = new StreamReader(@"C:\ProgramData\DMtools\AssetData\MonstersByAbilityScore.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = csv.GetRecords<Monster>();
                monsters = records.ToArray();
                reader.Close();
            }
            string[] monsterNames = new string[monsters.Length];
            for (int i = 0; i < monsters.Length; i++)
            {
                monsterNames[i] = monsters[i].Name;
            }
            monsterPicker.ItemsSource = monsterNames;

        }

        public void ReadOldData()
        {
            using (var reader = new StreamReader(monsterPath + Name + @"\MonsterStatistics.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = csv.GetRecords<Monster>();
                selectedMonster = records.ToArray();
                SetValues();
                chosenName.Text = Name;
            }
        }

        private void MonsterPicker_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedMonster[0] = monsters[monsterPicker.SelectedIndex];
            SetValues();
        }
        public void SetValues()
        {
            nameLabel.Content = "Name: " + selectedMonster[0].Name;
            typeLabel.Content = "Type: " + selectedMonster[0].Type;
            alignmentLabel.Content = "Alignment: " + selectedMonster[0].Alignment;
            sizeLabel.Content = "Size: " + selectedMonster[0].Size;
            acLabel.Content = "AC: " + selectedMonster[0].AC;
            hpLabel.Content = "HP: " + selectedMonster[0].HP;
            crLabel.Content = "CR: " + selectedMonster[0].CR;

            strLabel.Content = selectedMonster[0].STR;
            dexLabel.Content = selectedMonster[0].DEX;
            conLabel.Content = selectedMonster[0].CON;
            intLabel.Content = selectedMonster[0].INT;
            wisLabel.Content = selectedMonster[0].STR;
            chaLabel.Content = selectedMonster[0].CHA;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (Directory.Exists(monsterPath + @"\" + chosenName.Text) == false)
            {
                Directory.CreateDirectory(monsterPath + @"\" + chosenName.Text);
            }
            
            using (var writer = new StreamWriter(monsterPath + @"\" + chosenName.Text + @"\" + "MonsterStatistics.csv"))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.WriteRecords(selectedMonster);
            }

            this.Close();
        }
    }
    public class Monster
    {
        //All values are strings to avoid conversion errors when values have /_-|. in them
        public string Name { get; set; }
        public string Type { get; set; }
        public string Alignment { get; set; }
        public string Size { get; set; }
        public string CR { get; set; }
        public string AC { get; set; }
        public string HP { get; set; }
        public string STR { get; set; }
        public string DEX { get; set; }
        public string CON { get; set; }
        public string INT { get; set; }
        public string WIS { get; set; }
        public string CHA { get; set; }
    }
}
