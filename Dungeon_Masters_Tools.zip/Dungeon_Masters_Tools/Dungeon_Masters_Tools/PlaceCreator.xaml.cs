﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Dungeon_Masters_Tools
{
    /// <summary>
    /// Interaction logic for PlaceCreator.xaml
    /// </summary>
    public partial class PlaceCreator : Window
    {
        //Int used to know if making building, town or city respectively
        int t = 0;
        string datapath = "";
        public PlaceCreator(int type, string dp)
        {
            InitializeComponent();
            t = type;
            datapath = dp;
            if (type == 1)
            {
                placeNameLabel.Content = "Building Name";
                praceLabel.Content = "Common Races";
                rulersLabel.Content = "Building Owners";
                langLabel.Content = "Spoken Languages";
            }
            else if (type == 2)
            {
                placeNameLabel.Content = "Town Name";
                praceLabel.Content = "Common Races/Prominent Race";
                rulersLabel.Content = "Town Owners/Sherrifs/Protectors";
                langLabel.Content = "Spoken Languages/Prominent Language";
            }
            else if (type == 3)
            {
                placeNameLabel.Content = "Castle Name";
                praceLabel.Content = "Common Races/Prominent Race";
                rulersLabel.Content = "Castle Rulers";
                langLabel.Content = "Spoken Languages/Prominent Language";
            }


        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (t == 1)
            {
                Building b = new Building();
                b.Name = nameInput.Text;
                b.Languages = langInput.Text;
                b.Owners = rulerInput.Text;
                b.Information = infoInput.Text;
                b.Races = raceInput.Text;
                Building[] buildings = new Building[1];
                buildings[0] = b;
                using (var writer = new StreamWriter(datapath + @"\Places\buildings.csv"))
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    csv.WriteRecords(buildings);
                }
            }
            else if (t == 2)
            {
                Town t = new Town();
                t.Name = nameInput.Text;
                t.Languages = langInput.Text;
                t.Sherrifs = rulerInput.Text;
                t.Information = infoInput.Text;
                t.Races = raceInput.Text;
            }
            else if (t == 3)
            {
                Castle c = new Castle();
                c.Name = nameInput.Text;
                c.Languages = langInput.Text;
                c.Rulers = rulerInput.Text;
                c.Information = infoInput.Text;
                c.Races = raceInput.Text;
            }
        }
    }

    class Building
    {
        public string Name { get; set; }
        public string Races { get; set; }
        public string Owners { get; set; }
        public string Languages { get; set; }
        public string Information { get; set; }
    }
    class Town
    {
        public string Name { get; set; }
        public string Races { get; set; }
        public string Sherrifs { get; set; }
        public string Languages { get; set; }
        public string Information { get; set; }
    }
    class Castle
    {
        public string Name { get; set; }
        public string Races { get; set; }
        public string Rulers { get; set; }
        public string Languages { get; set; }
        public string Information { get; set; }
    }
}
