﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Dungeon_Masters_Tools
{
    /// <summary>
    /// Interaction logic for PlaceCreator.xaml
    /// </summary>
    public partial class PlaceCreator : Window
    {
        //Int used to know if making building, town or city respectively
        int t = 0;
        string datapath = "";
        public Building prevBuilding { get; set; }
        public Town prevTown;
        public Castle prevCastle;

        public PlaceCreator(Places_Menu pm, int type, string dp, bool isnew)
        {
            InitializeComponent();
            t = type;
            datapath = dp;
            if (type == 1)
            {
                placeNameLabel.Content = "Building Name";
                praceLabel.Content = "Common Races";
                rulersLabel.Content = "Building Owners";
                langLabel.Content = "Spoken Languages";
            }
            else if (type == 2)
            {
                placeNameLabel.Content = "Town Name";
                praceLabel.Content = "Common Races/Prominent Race";
                rulersLabel.Content = "Town Owners/Sherrifs/Protectors";
                langLabel.Content = "Spoken Languages/Prominent Language";
            }
            else if (type == 3)
            {
                placeNameLabel.Content = "Castle Name";
                praceLabel.Content = "Common Races/Prominent Race";
                rulersLabel.Content = "Castle Rulers";
                langLabel.Content = "Spoken Languages/Prominent Language";
            }
            if (isnew == false)
            {
                
                if (type == 1)
                {
                    prevBuilding = pm.selectedBuilding;
                    nameInput.Text = prevBuilding.Name;
                    raceInput.Text = prevBuilding.Races;
                    rulerInput.Text = prevBuilding.Owners;
                    langInput.Text = prevBuilding.Languages;
                    infoInput.Text = prevBuilding.Information;
                }
                if (type == 2)
                {
                    prevTown = pm.selectedTown;
                    nameInput.Text = prevTown.Name;
                    raceInput.Text = prevTown.Races;
                    rulerInput.Text = prevTown.Sherrifs;
                    langInput.Text = prevTown.Languages;
                    infoInput.Text = prevTown.Information;
                }
                if (type == 3)
                {
                    prevCastle = pm.selectedCastle;
                    nameInput.Text = prevCastle.Name;
                    raceInput.Text = prevCastle.Races;
                    rulerInput.Text = prevCastle.Rulers;
                    langInput.Text = prevCastle.Languages;
                    infoInput.Text = prevCastle.Information;
                }
            }



        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (t == 1)
            {
                Building b = new Building();
                b.Name = nameInput.Text;
                b.Languages = langInput.Text;
                b.Owners = rulerInput.Text;
                b.Information = infoInput.Text;
                b.Races = raceInput.Text;
                List<Building> buildings;
                using (var reader = new StreamReader(datapath + @"\Places\Buildings.csv"))
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {
                    
                    var records = csv.GetRecords<Building>();
                    buildings = records.ToList();
                    reader.Close();
                }
                buildings.Add(b);
                using (var writer = new StreamWriter(datapath + @"\Places\buildings.csv"))
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    csv.WriteRecords(buildings);
                }
                this.Close();
            }
            else if (t == 2)
            {
                Town t = new Town();
                t.Name = nameInput.Text;
                t.Languages = langInput.Text;
                t.Sherrifs = rulerInput.Text;
                t.Information = infoInput.Text;
                t.Races = raceInput.Text;
                List<Town> towns;
                using (var reader = new StreamReader(datapath + @"\Places\Towns.csv"))
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {

                    var records = csv.GetRecords<Town>();
                    towns = records.ToList();
                    reader.Close();
                }
                towns.Add(t);
                using (var writer = new StreamWriter(datapath + @"\Places\towns.csv"))
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    csv.WriteRecords(towns);
                }
                this.Close();
            }
            else if (t == 3)
            {
                Castle c = new Castle();
                c.Name = nameInput.Text;
                c.Languages = langInput.Text;
                c.Rulers = rulerInput.Text;
                c.Information = infoInput.Text;
                c.Races = raceInput.Text;
                List<Castle> castles;
                using (var reader = new StreamReader(datapath + @"\Places\castles.csv"))
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {

                    var records = csv.GetRecords<Castle>();
                    castles = records.ToList();
                    reader.Close();
                }
                castles.Add(c);
                using (var writer = new StreamWriter(datapath + @"\Places\castles.csv"))
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    csv.WriteRecords(castles);
                }
                this.Close();
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }

    public class Building
    {
        public string Name { get; set; }
        public string Races { get; set; }
        public string Owners { get; set; }
        public string Languages { get; set; }
        public string Information { get; set; }
    }
    public class Town
    {
        public string Name { get; set; }
        public string Races { get; set; }
        public string Sherrifs { get; set; }
        public string Languages { get; set; }
        public string Information { get; set; }
    }
    public class Castle
    {
        public string Name { get; set; }
        public string Races { get; set; }
        public string Rulers { get; set; }
        public string Languages { get; set; }
        public string Information { get; set; }
    }
}
