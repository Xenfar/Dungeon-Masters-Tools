﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dungeon_Masters_Tools
{
    /// <summary>
    /// Interaction logic for Campaign_Menu.xaml
    /// </summary>
    public partial class Campaign_Menu : Page
    {
        MainWindow mainWindow;
        string campaignPath;
        string startupPath;
        public Campaign_Menu(string camPath, MainWindow mW)
        {
            InitializeComponent();
            startupPath = AppDomain.CurrentDomain.BaseDirectory;
            campaignPath = camPath;
            mainWindow = mW;
            characImage.Source = new BitmapImage(new Uri(startupPath + @"\Assets\characters.png", UriKind.RelativeOrAbsolute));
            CharacterButton.Height = characImage.Source.Height / 2.06;
            CharacterButton.Width = characImage.Source.Width / 2.06;

            mapImage.Source = new BitmapImage(new Uri(startupPath + @"\Assets\defaultmap.jpg", UriKind.RelativeOrAbsolute));

        }

        private void CharacterButton_Click(object sender, RoutedEventArgs e)
        {
            Characters_Menu cm = new Characters_Menu(campaignPath, mainWindow);
            mainWindow.MainFrame.Content = cm;
        }

        private void MapButton_Click(object sender, RoutedEventArgs e)
        {
            MapViewer mv = new MapViewer(campaignPath, startupPath + @"Assets\");
            mv.ShowDialog();
        }

        private void PlacesButton_Click(object sender, RoutedEventArgs e)
        {
            PlaceCreator pc = new PlaceCreator(1, campaignPath);
            pc.ShowDialog();
            //should open menu first not the creator
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            mainWindow.MainFrame.Content = mainWindow.cm;
        }
    }
}
